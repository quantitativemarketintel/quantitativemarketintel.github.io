# models.py

import torch
import torch.nn as nn
from torch import optim
import numpy as np
import random
from sentiment_data import *


class SentimentClassifier(object):
    """
    Sentiment classifier base type
    """

    def predict(self, ex_words: List[str]) -> int:
        """
        Makes a prediction on the given sentence
        :param ex_words: words to predict on
        :return: 0 or 1 with the label
        """
        raise Exception("Don't call me, call my subclasses")

    def predict_all(self, all_ex_words: List[List[str]]) -> List[int]:
        """
        You can leave this method with its default implementation, or you can override it to a batched version of
        prediction if you'd like. Since testing only happens once, this is less critical to optimize than training
        for the purposes of this assignment.
        :param all_ex_words: A list of all exs to do prediction on
        :return:
        """
        return [self.predict(ex_words) for ex_words in all_ex_words]


class TrivialSentimentClassifier(SentimentClassifier):
    def predict(self, ex_words: List[str]) -> int:
        """
        :param ex:
        :return: 1, always predicts positive class
        """
        return 1

class DAN(nn.Module):
    def __init__(self, inp, hid, out, embedding_vecs):
        """
        Constructs the computation graph by instantiating the various layers and initializing weights.

        :param inp: size of input (integer)
        :param hid: size of hidden layer(integer)
        :param out: size of output (integer), which should be the number of classes
        """
        super(DAN, self).__init__()
        # takes in an array of vectors
        self.embeddings = nn.Embedding.from_pretrained(embedding_vecs)
        self.embeddings.weight.requires_grad = False
        # input layer
        self.V = nn.Linear(inp, hid)
        # activation 
        self.g = nn.ReLU()
        # hidden layer
        self.W = nn.Linear(hid, out)
        # softmax
        self.log_softmax = nn.LogSoftmax(dim=0)

        # Initialize weights according to a formula due to Xavier Glorot.
        nn.init.xavier_uniform_(self.V.weight)
        nn.init.xavier_uniform_(self.W.weight)

    def forward(self, idx):
        """
        Runs the neural network on the given data and returns log probabilities of the various classes.

        :param x: a [inp]-sized tensor of input data
        :return: an [out]-sized tensor of log probabilities. (In general your network can be set up to return either log
        probabilities or a tuple of (loss, log probability) if you want to pass in y to this function as well
        """
        return self.log_softmax((self.W(self.g(self.V(torch.mean(self.embeddings(idx), 0))))))


class NeuralSentimentClassifier(SentimentClassifier):
    """
    Implement your NeuralSentimentClassifier here. This should wrap an instance of the network with learned weights
    along with everything needed to run it on new data (word embeddings, etc.)
    """
    def __init__(self, deep_avg_network, word_embeddings, learning_rate, num_classes):
        self.word_embeddings = word_embeddings
        self.deep_avg_network = deep_avg_network
        self.lr = learning_rate
        self.num_classes = num_classes
        self.optimizer = optim.Adam(self.deep_avg_network.parameters(), lr=learning_rate)

    def predict(self, ex_words: List[str]) -> int:
        log_probabilities = self.deep_avg_network.forward(self.get_word_indices(ex_words))
        return torch.argmax(log_probabilities).item()

    def get_word_indices(self, words):
        idx = []
        for word in words:
            index = self.word_embeddings.word_indexer.index_of(word)
            if index != -1:
                idx.append(index)
            else:
                idx.append(self.word_embeddings.word_indexer.index_of("UNK"))
        return torch.LongTensor(idx)

    def train(self, ex):
        # index into the list of word embedding vectors
        idx = self.get_word_indices(ex.words)
        y = ex.label
        y_onehot = torch.zeros(self.num_classes)
        y_onehot.scatter_(0, torch.from_numpy(np.asarray(y,dtype=np.int64)), 1)
        self.deep_avg_network.zero_grad()
        #forward pass
        log_probs = self.deep_avg_network.forward(idx)
        #NLLloss - negative log likelihood loss, also known as crossentropy loss
        loss = torch.neg(log_probs).dot(y_onehot)
        # backpropagation based on our log loss training objective
        loss.backward()
        self.optimizer.step()
        return loss

def train_deep_averaging_network(args, train_exs: List[SentimentExample], dev_exs: List[SentimentExample], word_embeddings: WordEmbeddings) -> NeuralSentimentClassifier:
    """
    :param args: Command-line args so you can access them here
    :param train_exs: training examples
    :param dev_exs: development set, in case you wish to evaluate your model during training
    :param word_embeddings: set of loaded word embeddings
    :return: A trained NeuralSentimentClassifier model
    """
    initial_learning_rate = args.lr
    r = random.Random(1)
    word_embedding_length = word_embeddings.get_embedding_length()
    embedding_vecs = torch.FloatTensor(word_embeddings.vectors)
    deep_avg_network = DAN(word_embedding_length, args.hidden_size, 2, embedding_vecs)
    nn_classifier = NeuralSentimentClassifier(deep_avg_network, word_embeddings, initial_learning_rate, 2)
    for epoch in range(0, args.num_epochs):
        # shuffle our training examples
        r.shuffle(train_exs)
        total_loss = 0.0
        for ex in train_exs:
            total_loss += nn_classifier.train(ex)
        print("Total loss on epoch %i: %f" % (epoch, total_loss))
    return nn_classifier



